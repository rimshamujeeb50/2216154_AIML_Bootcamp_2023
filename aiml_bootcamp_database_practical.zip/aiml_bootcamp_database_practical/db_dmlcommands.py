import sqlite3

"bootcamp2023.db"
conn = sqlite3.connect("bootcamp2023.db")
print(conn)
#describe
s=''' pragma table_info(participants) '''
d=conn.execute(s)
print(d)
for i in d:
    print(i)
conn.execute("insert into participants values(1013 , 'Rimsha','btech','rimsha@gmail.com')")
conn.execute("insert into participants values(1001 , 'hasifa','btech','hasifa@gmail.com')")
conn.execute("insert into participants values(1100 , 'saba','btech','saba@gmail.com')")
conn.execute("insert into participants values(1063 , 'vysh','btech','vysh@gmail.com')")
print(conn.total_changes)
conn.commit()
##select command
records=conn.execute("select * from participants")
for i in records :
    print(i)