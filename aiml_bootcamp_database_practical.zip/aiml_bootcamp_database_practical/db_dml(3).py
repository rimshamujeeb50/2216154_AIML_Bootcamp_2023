#drop --- drop table table_name

import sqlite3

"bootcamp2023.db"
conn = sqlite3.connect("bootcamp2023.db")
print(conn)

#conn.execute("drop table participants")
conn.execute("rollback")
