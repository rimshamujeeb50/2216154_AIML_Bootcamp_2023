import sqlite3

"bootcamp2023.db"
conn = sqlite3.connect("bootcamp2023.db")
print(conn)

'''update table table_name  set coloumn_name ='new value' where condition'''
conn.execute("update participants set name='vyshnavi',email_id='vyshnavi@gmail.com' where G_ID =1063")
conn.commit()
##select command
records=conn.execute("select * from participants")
for i in records :
    print(i)

##delete  delete table_name where condition
conn.execute("delete from participants where g_id=1001")
conn.commit()

##select command
records=conn.execute("select * from participants")
for i in records :
    print(i)