'''
1.import the module
2.create database
3.establish connection with database
4.create a table with database--participants--write query
4.execute query
'''
import sqlite3

"bootcamp2023.db"
conn = sqlite3.connect("bootcamp2023.db")
query = ''' create table participants(G_id int primary key,name text not null,study text not null DEFAULT BTech)'''
#conn.execute(query)


#describe
s=''' pragma table_info(participants) '''
d=conn.execute(s)
print(d)
for i in d:
    print(i)

#alter--add new coloumn in already existing table

'''alter table table_name add coloumn datatype constrains'''
##conn.execute('alter table participants add column mail_id text not null')
conn.commit()
#conn.close()
#'''rename attribute'''
conn.execute('alter table participants rename column mail_id to email_id')

