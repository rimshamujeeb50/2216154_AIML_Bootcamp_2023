x="demonstrates mainpackage"
def mainpackdemo():
    return "main pack demo instruction"