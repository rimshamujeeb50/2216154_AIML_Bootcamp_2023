import sqlite3
"bootcamp2023.db"
conn=sqlite3.connect("bootcamp2023.db")
def get_records():

    records=conn.execute("select * from participants")
    for i in records :
        print(i)
    conn.commit()