import sqlite3
"bootcamp2023.db"
conn=sqlite3.connect("bootcamp2023.db")

def update_name(id,n):
    conn.execute("update participants set name='"+n+"' where g_id='"+str(id)+"'")
    conn.commit()