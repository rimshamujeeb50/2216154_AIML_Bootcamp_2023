import sqlite3
"bootcamp2023.db"
conn=sqlite3.connect("bootcamp2023.db")
def fetch_on_branch():

    b=input("enter the branch required:")
    print("the participants are:")
    r=conn.execute("select * from participants where branch='"+b+"'")
    for i in r :
        print(i)
    conn.commit()
