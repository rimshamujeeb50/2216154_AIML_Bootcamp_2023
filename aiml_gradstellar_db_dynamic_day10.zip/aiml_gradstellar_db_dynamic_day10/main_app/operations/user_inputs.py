import sqlite3
conn=sqlite3.connect("bootcamp2023.db")

def input_data():
    g_id=int(input("enter id"))
    name=input("enter name")
    branch=input("enter branch")
    study=input("enter study")
    data={}#dict
    data['g_id']=g_id
    data['name'] = name
    data['branch'] = branch
    data['study']=study
    conn.execute('''
            insert into participants(g_id,name,branch,study) values (?,?,?,?)
            ''',(data.get("g_id"),data.get("name"),data.get("branch"),data.get("study")))
    conn.commit()
    print("data inserted succesfully!!!")
    #conn.close()
    return data