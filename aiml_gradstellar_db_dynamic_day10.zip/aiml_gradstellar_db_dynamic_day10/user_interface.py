from main_app.operations import user_inputs as u
from main_app.operations import fetch_records as f
from main_app.operations import fetch_on_branch as fb
from main_app.operations import update_name as un
while(True):

   print('''
   1.enter participant details
   2.fetch the participant record
   3.fetch the participants based on branch
   4.update name
   5.exit
   ''')
   print("choose any option from above")
   ch=int(input())
   if ch==1:
      print("U can now enter values")
      u.input_data()
   elif ch==2:
      print("The records are:")
      f.get_records()
   elif ch==3:
      fb.fetch_on_branch()
   elif ch==4:
      id=int(input("enter the gid of participant:"))
      n=input("enter the name to be update")
      un.update_name(id,n)
   else:
      break
