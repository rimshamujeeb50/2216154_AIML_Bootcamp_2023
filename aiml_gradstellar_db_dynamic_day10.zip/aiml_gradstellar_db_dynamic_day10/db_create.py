import sqlite3

"bootcamp2023.db"
conn = sqlite3.connect("bootcamp2023.db")
query = ''' create table participants(G_id int primary key,name text not null,branch text not null,study text not null DEFAULT BTech)'''
conn.execute(query)